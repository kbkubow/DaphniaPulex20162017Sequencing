git clone https://github.com/odelaneau/shapeit4.git

module load gcc/9.2.0
module load boost/1.68.0
module load htslib/1.9
